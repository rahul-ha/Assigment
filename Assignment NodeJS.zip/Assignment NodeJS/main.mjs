import greeting from "./greeting.mjs";

console.log(greeting("Arvind"));



import { add, sub, mul, div } from "./operations.mjs";

console.log(add(10,20));
console.log(sub(20,10));
console.log(mul(10,20));
console.log(div(20,10));