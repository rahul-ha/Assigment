function greeting(name){
    let msg = `Hello, ${name}! Welcome to the Node.js module system."`; 
    return msg;
}
export default greeting;